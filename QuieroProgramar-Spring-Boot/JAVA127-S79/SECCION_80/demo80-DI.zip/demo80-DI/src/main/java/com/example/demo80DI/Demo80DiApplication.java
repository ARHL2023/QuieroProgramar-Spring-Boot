package com.example.demo80DI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo80DiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Demo80DiApplication.class, args);
	}

}
