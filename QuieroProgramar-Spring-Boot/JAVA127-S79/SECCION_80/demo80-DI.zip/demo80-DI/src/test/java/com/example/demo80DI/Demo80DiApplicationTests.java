package com.example.demo80DI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo80DiApplicationTests {

	@Test
	void contextLoads() {
	}

}
