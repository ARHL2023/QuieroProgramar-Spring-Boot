package com.example.demo80DIPRACTICEFACTURA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo80DipracticefacturaApplicationTests {

	@Test
	void contextLoads() {
	}

}
