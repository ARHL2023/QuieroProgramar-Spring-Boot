package com.bolsadeideas.springboot.form.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo81FormsApplication {

	public static void main(String[] args) {
		SpringApplication.run(Demo81FormsApplication.class, args);
	}

}
