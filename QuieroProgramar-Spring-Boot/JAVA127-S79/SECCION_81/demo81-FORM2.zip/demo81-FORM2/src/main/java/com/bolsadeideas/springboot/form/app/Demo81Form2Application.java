package com.bolsadeideas.springboot.form.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo81Form2Application {

	public static void main(String[] args) {
		SpringApplication.run(Demo81Form2Application.class, args);
	}

}
