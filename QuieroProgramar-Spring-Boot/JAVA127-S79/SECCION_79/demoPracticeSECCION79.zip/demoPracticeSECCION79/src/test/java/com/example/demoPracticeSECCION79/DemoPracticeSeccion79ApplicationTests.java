package com.example.demoPracticeSECCION79;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoPracticeSeccion79ApplicationTests {

	@Test
	void contextLoads() {
	}

}
